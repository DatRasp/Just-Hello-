Учебный проект "Барбершоп Borodinski" базового интенсива <a href="https://htmlacademy.ru" target="_blank">HTML Academy</a><br>
Фиксированная вёрстка, HTML5, CSS3, нативный JavaScript, прогрессивное улучшение<br>
<br>

---

<img align="left" width="50" height="50" alt="HTML Academy" src="https://up.htmlacademy.ru/static/img/intensive/htmlcss/logo-for-github-2.png">

Репозиторий создан для обучения на интенсивном онлайн‑курсе «[Профессиональный HTML и CSS, уровень 1](https://htmlacademy.ru/intensive/htmlcss)» от [HTML Academy](https://htmlacademy.ru).
